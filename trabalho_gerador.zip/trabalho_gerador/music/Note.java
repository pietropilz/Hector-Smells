package music;

public class Note {
	private int semitone;
	private int duration;

	public Note(int semitone, int duration) {
		this.semitone = semitone;
		this.duration = duration;
	}

	public int getSemitone() {
		return this.semitone;
	}

	public int getDuration() {
		return this.duration;
	}
}