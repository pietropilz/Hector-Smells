package music;

public class Note {
	public static final int DO = 0;
	public static final int DO_ = 1;
	public static final int RE = 2;
	public static final int RE_ = 3;
	public static final int MI = 4;
	public static final int FA = 5;
	public static final int FA_ = 6;
	public static final int SOL = 7;
	public static final int SOL_ = 8;
	public static final int LA = 9;
	public static final int LA_ = 10;
	public static final int SI = 11;
	public static final int DEFAULT_DURATION = 4;
	public static final int MAX_SEMITONE = 127;

	private int semitone;
	private int duration;

	public Note(int semitone, int duration) {
		this.semitone = semitone;
		this.duration = duration;
	}

	public int getSemitone() {
		return this.semitone;
	}

	public int getDuration() {
		return this.duration;
	}
}