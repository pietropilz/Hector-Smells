package music;

import javax.sound.midi.*;

public class SoundTrack {
	public static final int TIME_BEGIN = 24;

	private int volume;
	private int octave;

	private Track track;
	private int channel;
	private int tick;

	public SoundTrack(Track track) {
		this.octave = -1;
		this.volume = 0;
		
		this.track = track;
		this.channel = 0;
		this.tick = TIME_BEGIN;		
	}

	public int getVolume() {
		return this.volume;
	}

	public int getOctave() {
		return this.octave;
	}

	public Track getTrack() {
		return this.track;
	}
	
	public int getChannel() {
		return this.channel;
	}
	
	public int getCurrentTick() {
		return this.tick;
	}

	public void setTick(int tick) {
		this.tick = tick;
	}

	public void setOctave(int octave) {
		this.octave = octave;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	public void setChannel(int channel) {
		this.channel = channel;
	}

	public boolean changeInstrument(int instrument) {
		try {
			ShortMessage sm = new ShortMessage();
	        sm.setMessage(ShortMessage.PROGRAM_CHANGE, this.channel, instrument, 0);
	        track.add(new MidiEvent(sm, this.tick));

	        return true;
		}
		catch (InvalidMidiDataException e) {
			return false;
		}
	}

	private int getFullTone(int semitone) {
		return 12 * (this.octave + 1) + semitone;
	}

	public boolean addNote(Note note) {
		int semitone = note.getSemitone();
		int duration = note.getDuration();
		int fullTone = getFullTone(semitone);

		try{
			ShortMessage on = new ShortMessage();
	        on.setMessage(ShortMessage.NOTE_ON, this.channel, fullTone, this.volume);
	        this.track.add(new MidiEvent(on, this.tick));

	        ShortMessage off = new ShortMessage();
	        off.setMessage(ShortMessage.NOTE_OFF, this.channel, fullTone, this.volume);
	        this.track.add(new MidiEvent(off, this.tick + duration));

	        this.tick += duration;
	        return true;
		}
		catch (InvalidMidiDataException e) {
			return false;
		}
			
	}
}