package music;

import javax.sound.midi.*;

public class SoundTrack {
	public static final int TIME_BEGIN = 24;
	public static final int DEFAULT_VOLUME = 100;
	public static final int MAX_VOLUME = 127;
	public static final int DEFAULT_OCTAVE = -1;
	public static final int MAX_OCTAVE = 9;

	public static final int BANDONEON = 23;
	public static final int GAITA_DE_FOLES = 109;
	public static final int ONDAS_DO_MAR = 122;
	public static final int TUBULAR_BELLS = 14;
	public static final int AGOGO = 113;

	private int volume;
	private int octave;
	private int instrument;

	private Track track;
	private int channel;
	private int tick;

	public SoundTrack(Track track) {
		this.octave = DEFAULT_OCTAVE;
		this.volume = DEFAULT_VOLUME;
		this.instrument = 0;
		
		this.track = track;
		this.channel = 0;
		this.tick = TIME_BEGIN;		
	}

	public int getVolume() {
		return this.volume;
	}

	public int getOctave() {
		return this.octave;
	}

	public Track getTrack() {
		return this.track;
	}
	
	public int getChannel() {
		return this.channel;
	}
	
	public int getCurrentTick() {
		return this.tick;
	}

	public void setTick(int tick) {
		this.tick = tick;
	}

	public void setTrack(Track track) {
		this.track = track;
	}

	public void setOctave(int octave) {
		this.octave = octave;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	public void setChannel(int channel) {
		this.channel = channel;
	}

	public boolean changeInstrument(int instrument) {
		try {
			ShortMessage sm = new ShortMessage();
	        sm.setMessage(ShortMessage.PROGRAM_CHANGE, this.channel, instrument, 0);
	        track.add(new MidiEvent(sm, this.tick));
	        this.instrument = instrument;

	        return true;
		}
		catch (InvalidMidiDataException e) {
			return false;
		}
	}

	private int getFullTone(int semitone) {
		int fullTone = 12 * (this.octave + 1) + semitone;
		if (fullTone > Note.MAX_SEMITONE) {
			return Note.MAX_SEMITONE;
		}
		return fullTone;
	}

	public boolean isLetter(char character) {
		if (character == 'A' || character == 'B' || character == 'C' || character == 'D' || 
			character == 'E' || character == 'F' || character == 'G' || character == 'H') {
			return true;
		} 
		return false;
	}

	private boolean isEven(char character) {
		int integer = (int) character;
		if (integer == 2 || integer == 4 || integer == 6 || integer == 8 || integer == 0) {
			return true;
		}
		return false;
	}

	public boolean addNote(Note note) {
		int semitone = note.getSemitone();
		int duration = note.getDuration();
		int fullTone = getFullTone(semitone);

		try{
			ShortMessage on = new ShortMessage();
	        on.setMessage(ShortMessage.NOTE_ON, this.channel, fullTone, this.volume);
	        this.track.add(new MidiEvent(on, this.tick));

	        ShortMessage off = new ShortMessage();
	        off.setMessage(ShortMessage.NOTE_OFF, this.channel, fullTone, this.volume);
	        this.track.add(new MidiEvent(off, this.tick + duration));

	        this.tick += duration;
	        return true;
		}
		catch (InvalidMidiDataException e) {
			return false;
		}
	}

	public int charToNote(char character) {
		int newNote;
		switch (character) {
		case 'A':
			newNote = Note.LA;
			break;
		case 'B':
			newNote = Note.SI;
			break;
		case 'C':
			newNote = Note.DO;
			break;
		case 'D':
			newNote = Note.RE;
			break;
		case 'E':
			newNote = Note.MI;
			break;
		case 'F':
			newNote = Note.FA;
			break;
		case 'G':
			newNote = Note.SOL;
			break;
		case 'H':
			newNote = Note.LA_;
			break;
		default:
			newNote = -1;
		}

		return newNote;
	}

	public void processCharacter(char character, char previousCharacter, int previousNote) {
		switch (character) {
		case 'A':
		case 'B':
		case 'C':
		case 'D':
		case 'E':
		case 'F':
		case 'G':
		case 'H':
			int newNote = charToNote(character);
			this.addNote(new Note(newNote, Note.DEFAULT_DURATION));
			break;
		case 'a':
		case 'b':
		case 'c':
		case 'd':
		case 'e':
		case 'f':
		case 'g':
		case 'h':
			int temp = this.volume;
			this.volume = 0;
			this.addNote(new Note(0, Note.DEFAULT_DURATION));
			this.volume = temp;
			break;
		case ' ':
			int doubleVolume = this.volume * 2;
			if (doubleVolume > MAX_VOLUME) {
				this.volume = MAX_VOLUME;
			}
			else {
				this.volume = doubleVolume;
			}
			break;
		case '!':
			this.changeInstrument(BANDONEON);
			break;
		case 'i':
		case 'o':
		case 'u':
		case 'I':
		case 'O':
		case 'U':
			this.changeInstrument(GAITA_DE_FOLES);
			break;
		case 'j':
		case 'k':
		case 'l':
		case 'm':
		case 'n':
		case 'p':
		case 'q':
		case 'r':
		case 's':
		case 't':
		case 'v':
		case 'w':
		case 'x':
		case 'y':
		case 'z':
		case 'J':
		case 'K':
		case 'L':
		case 'M':
		case 'N':
		case 'P':
		case 'Q':
		case 'R':
		case 'S':
		case 'T':
		case 'V':
		case 'W':
		case 'X':
		case 'Y':
		case 'Z':
			if (isLetter(previousCharacter)) {
				this.addNote(new Note(previousNote, Note.DEFAULT_DURATION));
			}
			else {
				this.addNote(new Note(0, Note.DEFAULT_DURATION));
			}
			break;
		case '2':
		case '4':
		case '6':
		case '8':
		case '0':
			int digit = (int) character;
			int newInstrument = this.instrument + digit;
			this.changeInstrument(newInstrument);
			this.instrument = newInstrument;
			break;
		case '?':
			int newOctave = this.octave + 1;
			if (newOctave > MAX_OCTAVE) {
				this.octave = DEFAULT_OCTAVE;
			}
			else {
				this.octave = newOctave;
			}
			break;
		case '\n':
			this.changeInstrument(ONDAS_DO_MAR);
			break;
		case ';':
		case '1':
		case '3':
		case '5':
		case '7':
		case '9':
			this.changeInstrument(TUBULAR_BELLS);
			break;
		case ',':
			this.changeInstrument(AGOGO);
			break;
		default:
			if (isLetter(previousCharacter)) {
				this.addNote(new Note(previousNote, Note.DEFAULT_DURATION));
			}
			else {
				this.addNote(new Note(0, Note.DEFAULT_DURATION));
			}
		}
	}
}